﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppPrueba
{
    class productoRepositorio
    {
        public static List<Producto> Productos { get; set; }
        public static void IniciarRepositorio()
        {
            Productos = new List<Producto>();

            if(!File.Exists("productos.txt"))
            {
                StreamWriter archivo = new StreamWriter("productos.txt");
                archivo.Close();
            }
            else
            {
                StreamReader archivo = new StreamReader("productos.txt");
                while (!archivo.EndOfStream)
                {
                    string producto = archivo.ReadLine();
                    string[] datos = producto.Split(';');
                    Producto prod = new Producto()
                    {
                        Id = int.Parse(datos[0]),
                        Nombre = datos[1],
                        Categoria = datos[2],
                        Precio = int.Parse(datos[3]),
                        Stock = int.Parse(datos[4]),
                    

                    };
                    Productos.Add(prod);
                 
                }
                archivo.Close();
            }
        }
        public static void agregarProducto(Producto prod)
        {
            Productos.Add(prod);
            GuardarEnMemoria(prod);
        }
        public static void eliminarProducto(int id)
        {
            Productos.RemoveAll(e => e.Id.Equals(id));
            GuardarEnMemoriaLista();
        }
        public static void actualizarProducto(int id, Producto prod)
        {
            int index = Productos.FindIndex(e => e.Id.Equals(id));
            if (index != -1)
            {
                 Productos[index] = prod;
            }
            
            GuardarEnMemoriaLista();
        }
        public static void GuardarEnMemoria(Producto prod)
        {
         StreamWriter archivo = new StreamWriter("productos.txt", true);
            archivo.WriteLine(prod.Id + ";" + prod.Nombre + ";" + prod.Categoria + ";" + prod.Precio + ";" + prod.Stock);
            archivo.Close();
        }
        public static void GuardarEnMemoriaLista()
        {
            StreamWriter archivo = new StreamWriter("productos.txt");
            foreach (Producto prod in Productos)
            {
            archivo.WriteLine(prod.Id + ";" + prod.Nombre + ";" + prod.Categoria + ";" + prod.Precio + ";" + prod.Stock);

            }
            archivo.Close();
        }



    }
}
