﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppPrueba.Properties;

namespace WindowsFormsAppPrueba
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        /// 
        public static String Ruta_Base;
        public static String entorno = "casa";
        [STAThread]


       
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            







            Application.Run(new Menu());

            if (entorno == "casa")
            {

                Ruta_Base = @"C:\Users\MEGACOMPU\Desktop\WindowsFormsAppPrueba\WindowsFormsAppPrueba";
            }
            else
            {
                Ruta_Base = @"C:\Users\Alumno\Desktop\WindowsFormsAppPrueba\";
            }







        }
    }
}
