﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppPrueba.Properties;

namespace WindowsFormsAppPrueba
{
    public partial class Agregar : Form
    {
       
        public Agregar()
        {
            InitializeComponent();
        }
        public Agregar(Producto prod)
        {
            InitializeComponent();
            txtId.Text = prod.Id.ToString();
            txtNombre.Text = prod.Nombre.ToString();
            txtCategoria.Text = prod.Categoria.ToString();
            txtPrecio.Text = prod.Precio.ToString();
            txtStock.Text = prod.Stock.ToString();
        }
       public Producto productoNuevo;

        public Image File { get; private set; }

        private void Agregar_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCategoria_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtStock_TextChanged(object sender, EventArgs e)
        {

        }
        private bool ValidarProducto(out string errorMsg)
        {
            errorMsg = String.Empty;
            if (string.IsNullOrEmpty(txtNombre.Text))
            {
                errorMsg += "Debe indicar el Nombre del producto." + Environment.NewLine;

            }

            if (string.IsNullOrEmpty(listCategoria.Text))
            {
                errorMsg += "Debe indicar el Categoria del producto." + Environment.NewLine;

            }

            if (string.IsNullOrEmpty(txtPrecio.Text) || int.Parse(txtPrecio.Text) <=0)
            {
                errorMsg += "Debe indicar el Precio del producto\nEl precio no debe ser igual o menor que 0." + Environment.NewLine;
            }

            if (string.IsNullOrEmpty(txtStock.Text))
            {
                errorMsg += "Debe indicar el Stock del producto." + Environment.NewLine;
            }

            if (string.IsNullOrEmpty(txtNameImg.Text))
            {
                errorMsg += "Debe indicar el Nombre de la imagen del producto." + Environment.NewLine;
            }

            return errorMsg == String.Empty;

        }
        private void btnAceptar_Click(object sender, EventArgs e) {

            bool productoValidado = ValidarProducto(out string errorMsg);
            if (productoValidado)
            {

                try
                {
                    File.Save(@"C:\Users\MEGACOMPU\Desktop\WindowsFormsAppPrueba\WindowsFormsAppPrueba\Resources\img\productos\imagenes_final\" + txtNameImg.Text + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                }
                catch
                {

                }


                productoNuevo = new Producto()
                {

                    Id = int.Parse(txtId.Text),
                    Nombre = txtNombre.Text,
                    Categoria = listCategoria.Text,
                    Precio = int.Parse(txtPrecio.Text),
                    Stock = int.Parse(txtStock.Text)

                
                };
                this.DialogResult = DialogResult.OK;
            }
           else
            {
                MessageBox.Show(errorMsg,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult= DialogResult.Cancel;
            }

        }

        private void listCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnImg_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPG(*.JPG)|*.jpg";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                File = Image.FromFile(ofd.FileName);
                pictureBox1.Image = File;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }



} 
