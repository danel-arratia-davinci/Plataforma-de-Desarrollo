﻿using System;
using System.Drawing;

namespace WindowsFormsAppPrueba
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Categoria { get; set; }
        public int Precio { get; set; }

       
        public String Foto { get; set; }
        public int Stock { get; set; }
        public Producto()
        {

        }

        internal static int Findindex(Func<object, object> p)
        {
            throw new NotImplementedException();
        }
    }
}