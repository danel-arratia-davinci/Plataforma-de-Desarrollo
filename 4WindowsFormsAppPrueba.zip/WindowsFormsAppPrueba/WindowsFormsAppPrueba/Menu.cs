﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsAppPrueba.Properties;

namespace WindowsFormsAppPrueba
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
            productoRepositorio.IniciarRepositorio();
            VerProductos();
        }

        private void button1_Click(object sender, EventArgs e)
        {   
            Agregar agregar = new Agregar();    
            DialogResult dialogResult = agregar.ShowDialog();
            if(dialogResult == DialogResult.OK)
            {
                /// FORM AGREGAR PRODUCT
                productoRepositorio.agregarProducto(agregar.productoNuevo);
                VerProductos();
            }
        }

        private void VerProductos()
        {
            dataGridView1.Rows.Clear();
            foreach(Producto prod in productoRepositorio.Productos)
            {
                int rowIndex = dataGridView1.Rows.Add();
                dataGridView1.Rows[rowIndex].Cells[0].Value = prod.Id.ToString();
                dataGridView1.Rows[rowIndex].Cells[1].Value = prod.Nombre.ToString();
                dataGridView1.Rows[rowIndex].Cells[2].Value = prod.Categoria.ToString();
                dataGridView1.Rows[rowIndex].Cells[3].Value = prod.Precio.ToString();
                dataGridView1.Rows[rowIndex].Cells[4].Value = prod.Stock.ToString();

                /// Image File;

                ///string nombreFoto = prod.Foto;
                /// ERROR DE RUTA
                ///string ruta = Program.Ruta_Base + @"\Resources\img\productos\imagenes_final\" + nombreFoto + ".jpg";

                ///File = Image.FromFile(ruta);
                /// dataGridView1.Rows[rowIndex].Cells[5].Value = File;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string idCategoriaModificar = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string nombreCategoriaModificar = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string catCategoriaModificar = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string precioCategoriaModificar = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                string stockCategoriaModificar = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();



                Producto productoEditar = new Producto()
                {
                    Id = int.Parse(idCategoriaModificar),
                    Nombre = nombreCategoriaModificar,
                    Categoria = catCategoriaModificar,
                    Precio = int.Parse(precioCategoriaModificar),
                    Stock = int.Parse(stockCategoriaModificar),
                };

                Agregar agregar = new Agregar(productoEditar);
                DialogResult dialogResult = agregar.ShowDialog();

                if (dialogResult == DialogResult.OK)
                {
                    /// FORM Actualizar PRODUCT
                    productoRepositorio.actualizarProducto(int.Parse(idCategoriaModificar), agregar.productoNuevo);
                    VerProductos();
                }

              

            }
            else
            {
                MessageBox.Show("erRRROR", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string idCategoriaEliminar = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                productoRepositorio.eliminarProducto(int.Parse(idCategoriaEliminar));
                VerProductos();
            }else{
                MessageBox.Show("erRRROR", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       
    }
}
