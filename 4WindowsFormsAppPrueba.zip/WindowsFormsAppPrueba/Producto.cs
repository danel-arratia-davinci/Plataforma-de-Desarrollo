﻿using System;

public class Producto
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Categoria { get; set; }
    public int Precio { get; set; }
    public Producto()
    {

    }

    internal static int Findindex(Func<object, bool> value)
    {
        throw new NotImplementedException();
    }
}

